#!/bin/bash
# Bangun vyrontheme.blueprint lalu pasang. Jalankan di VPS sebagai root: bash build.sh
set -e
cd "$(dirname "$0")"
PTERO_DIR="${PTERO_DIR:-/var/www/pterodactyl}"
ID="vyrontheme"

command -v blueprint >/dev/null 2>&1 || { echo "!! Blueprint belum terpasang."; exit 1; }
command -v zip >/dev/null 2>&1 || apt-get install -y zip

# Samakan 'target' dengan versi Blueprint di VPS ini
RAW="$(blueprint -v 2>/dev/null | sed 's/\x1b\[[0-9;]*m//g' | head -n1 || true)"
TARGET="$(echo "$RAW" | awk '{print $NF}')"
if echo "$TARGET" | grep -qE '^[A-Za-z0-9._-]+$'; then
    sed -i "s/^  target: .*/  target: \"${TARGET}\"/" conf.yml
    echo ">>> Target diset ke: ${TARGET}"
else
    echo "!! Versi Blueprint tidak terbaca (\"${RAW}\"), target dibiarkan default."
fi

# Bangun ulang wrapper admin dari admin.css (supaya CSS admin dimuat di semua halaman admin)
{ echo '@verbatim'; echo '<style>'; cat admin/admin.css; echo '</style>'; echo '@endverbatim'; } > admin/wrapper.blade.php

rm -f "${PTERO_DIR}/${ID}.blueprint"
zip -qr "${PTERO_DIR}/${ID}.blueprint" . -x build.sh
echo ">>> Dibuat: ${PTERO_DIR}/${ID}.blueprint"

cd "${PTERO_DIR}"
if [ -d "${PTERO_DIR}/.blueprint/extensions/${ID}" ]; then
    echo ">>> Tema sudah terpasang, mencoba upgrade..."
    blueprint -upgrade "${ID}" || {
        echo ">>> Upgrade gagal, hapus lalu pasang ulang (jawab y kalau ditanya)..."
        blueprint -remove "${ID}"
        blueprint -install "${ID}"
    }
else
    blueprint -install "${ID}"
fi

# ---- Matikan reCAPTCHA (kuota gratis Google habis) ----
echo ">>> Mematikan reCAPTCHA..."
cp -n .env .env.bak-vyron 2>/dev/null || true
if grep -q '^RECAPTCHA_ENABLED=' .env; then
    sed -i 's/^RECAPTCHA_ENABLED=.*/RECAPTCHA_ENABLED=false/' .env
else
    echo 'RECAPTCHA_ENABLED=false' >> .env
fi
# Setting dari Admin > Settings > Advanced disimpan di database dan menimpa .env
php artisan tinker --execute="DB::table('settings')->updateOrInsert(['key'=>'settings::recaptcha:enabled'],['value'=>'false']);" || echo "!! Update DB gagal, matikan manual di Admin > Settings > Advanced"

# ---- Bersihkan cache ----
php artisan view:clear
php artisan config:clear
php artisan cache:clear
systemctl restart pteroq 2>/dev/null || true
echo ">>> Selesai. Hard refresh browser (atau buka tab incognito)."
