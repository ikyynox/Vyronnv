@verbatim
<script>
(function () {
  if (window.__vyHeader) return;
  window.__vyHeader = true;

  // Ubah teks status di sini kalau mau
  var STATUS = {
    running:  { cls: 'vy-on',   text: '\u2714 ONLINE \u00B7 JANGAN MELEBIHI BATAS CPU & RAM!' },
    offline:  { cls: 'vy-off',  text: '\u26A0 SERVER MATI! CEK CONSOLE SEBELUM START!' },
    starting: { cls: 'vy-warn', text: '\u26A0 SEDANG START \u00B7 JANGAN SPAM TOMBOL!' },
    stopping: { cls: 'vy-warn', text: '\u26A0 SEDANG STOP \u00B7 TUNGGU SAMPAI MATI!' }
  };
  var SUSPENDED = { cls: 'vy-off', text: '\u26A0 DITANGGUHKAN \u00B7 HUBUNGI ADMIN!' };
  var LOADING = { cls: 'vy-warn', text: 'Memuat\u2026' };

  var ICON = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 3 7.5 12 12l9-4.5z"/><path d="M3 12l9 4.5 9-4.5"/><path d="M3 16.5 12 21l9-4.5"/></svg>';
  var cur = { id: null, name: '', state: null, suspended: false, last: 0, busy: false };

  function sid() {
    var m = location.pathname.match(/^\/server\/([^\/?#]+)/);
    return m ? m[1] : null;
  }

  function get(path) {
    return fetch('/api/client/servers/' + path, {
      credentials: 'same-origin',
      headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (r) {
      if (!r.ok) throw new Error(r.status);
      return r.json();
    });
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }

  function build(id) {
    var h = el('div');
    h.id = 'vy-server-header';
    var back = el('a', 'vy-back', '\u2039');
    back.href = '/';
    back.setAttribute('aria-label', 'Kembali');
    var icon = el('div', 'vy-icon');
    icon.innerHTML = ICON;
    var meta = el('div', 'vy-meta');
    meta.appendChild(el('div', 'vy-name', '\u2026'));
    meta.appendChild(el('div', 'vy-status vy-warn', 'Memuat\u2026'));
    var more = el('a', 'vy-more', '\u22EE');
    more.href = '/server/' + id + '/settings';
    more.setAttribute('aria-label', 'Pengaturan');
    h.appendChild(back); h.appendChild(icon); h.appendChild(meta); h.appendChild(more);
    return h;
  }

  function paint(h) {
    if (!h) return;
    var n = h.querySelector('.vy-name');
    var s = h.querySelector('.vy-status');
    if (n) n.textContent = cur.name || '\u2026';
    var st = cur.suspended ? SUSPENDED : (STATUS[cur.state] || LOADING);
    if (s) { s.className = 'vy-status ' + st.cls; s.textContent = st.text; }
  }

  function refresh() {
    var now = Date.now();
    if (cur.busy || now - cur.last < 5000) { paint(document.getElementById('vy-server-header')); return; }
    cur.busy = true; cur.last = now;
    var id = cur.id, jobs = [];
    if (!cur.name) {
      jobs.push(get(id).then(function (j) {
        cur.name = j.attributes.name || '';
        cur.suspended = !!j.attributes.is_suspended;
      }));
    }
    jobs.push(get(id + '/resources').then(function (j) {
      cur.state = j.attributes.current_state;
    }));
    Promise.all(jobs).catch(function () {}).then(function () {
      cur.busy = false;
      paint(document.getElementById('vy-server-header'));
    });
  }

  function tick() {
    try {
      var id = sid();
      var old = document.getElementById('vy-server-header');
      if (!id) { if (old) old.remove(); cur.id = null; return; }
      if (cur.id !== id) {
        cur = { id: id, name: '', state: null, suspended: false, last: 0, busy: false };
        if (old) { old.remove(); old = null; }
      }
      if (!old) {
        var link = document.querySelector('a[href="/server/' + id + '/files"]');
        if (!link) return;
        var bar = link.parentElement;
        for (var i = 0; i < 3 && bar.parentElement && bar.parentElement.children.length === 1; i++) {
          bar = bar.parentElement;
        }
        bar.classList.add('vy-tabbar');
        bar.parentNode.insertBefore(build(id), bar);
      }
      refresh();
    } catch (e) {}
  }


  // ---- Putihkan semua blok abu-abu (tab bar, grafik, tombol abu) berdasarkan warna aslinya ----
  var TAGS = { DIV: 1, NAV: 1, BUTTON: 1, SECTION: 1, A: 1, LI: 1, UL: 1, HEADER: 1, MAIN: 1 };
  function isGrayBg(cs) {
    var m = cs.backgroundColor.match(/rgba?\(([^)]+)\)/);
    if (!m) return false;
    var p = m[1].split(',').map(parseFloat);
    var a = p.length > 3 ? p[3] : 1;
    if (a < 0.9) return false;
    var mx = Math.max(p[0], p[1], p[2]), mn = Math.min(p[0], p[1], p[2]);
    var l = (mx + mn) / 510, d = mx - mn;
    var s = d === 0 ? 0 : (d / 255) / (1 - Math.abs(2 * l - 1));
    return l > 0.25 && l < 0.5 && s < 0.3;
  }
  function whiten() {
    try {
      var all = document.body.getElementsByTagName('*');
      for (var i = 0; i < all.length; i++) {
        var e = all[i];
        if (!TAGS[e.tagName] || e.classList.contains('vy-white')) continue;
        if (e.closest('#vy-server-header')) continue;
        var r = e.getBoundingClientRect();
        if (r.width < 40 || r.height < 28 || r.width * r.height < 1500) continue;
        if (isGrayBg(getComputedStyle(e))) e.classList.add('vy-white');
      }
    } catch (x) {}
  }
  setInterval(whiten, 800);


  // ---- Bungkus console + kolom command jadi satu kartu membulat ----
  function wrapTerminal() {
    try {
      var t = document.getElementById('terminal');
      if (!t) return;
      var inp = document.querySelector('input[aria-label="Console command input."]');
      var w = t.parentElement;
      if (inp) { while (w && w !== document.body && !w.contains(inp)) w = w.parentElement; }
      if (w && w !== document.body && !w.classList.contains('vy-term')) w.classList.add('vy-term');
    } catch (x) {}
  }
  setInterval(wrapTerminal, 800);

  setInterval(tick, 1000);
  tick();
})();
</script>
@endverbatim
