@verbatim
<style>
/* VYRON THEME v1.0 - area admin */
:root{
  --vy-bg:#0a0b11; --vy-bg2:#0f111a; --vy-surface:#141725; --vy-surface2:#1a1e30;
  --vy-border:#272c42; --vy-text:#e8eaf4; --vy-muted:#8d93ad;
  --vy-violet:#8b5cf6; --vy-fuchsia:#d946ef; --vy-cyan:#22d3ee;
  --vy-green:#34d399; --vy-amber:#fbbf24; --vy-orange:#fb923c; --vy-red:#fb7185;
  --vy-grad:linear-gradient(135deg,#8b5cf6 0%,#d946ef 100%);
  --vy-radius:14px;
}

body,.skin-blue .wrapper,.skin-blue .content-wrapper,.content-wrapper,.right-side{
  background:var(--vy-bg)!important;color:var(--vy-text);
  font-family:Inter,"Segoe UI",system-ui,-apple-system,Roboto,sans-serif;
}
.skin-blue .main-header .logo{background:#0c0e16!important;color:#fff!important;font-weight:800;letter-spacing:.14em;border-bottom:1px solid var(--vy-border)}
.skin-blue .main-header .logo:hover{background:#10121b!important}
.skin-blue .main-header .navbar{background:#0c0e16!important;border-bottom:1px solid var(--vy-border)}
.skin-blue .main-header .navbar .sidebar-toggle:hover,.skin-blue .main-header .navbar .nav>li>a:hover{background:rgba(139,92,246,.15)!important}
.skin-blue .main-sidebar,.skin-blue .left-side{background:#0c0e16!important}
.skin-blue .sidebar-menu>li.header{background:#0a0b11!important;color:var(--vy-muted)!important;letter-spacing:.12em}
.skin-blue .sidebar-menu>li>a{color:#b6bbd3!important}
.skin-blue .sidebar-menu>li:hover>a,.skin-blue .sidebar-menu>li.active>a{
  background:rgba(139,92,246,.12)!important;color:#fff!important;border-left-color:var(--vy-violet)!important}
.skin-blue .sidebar-menu>li>.treeview-menu{background:#0a0b11!important}
.content-header>h1{color:#fff}.content-header>h1>small{color:var(--vy-muted)}
.content-wrapper a:not(.btn){color:var(--vy-cyan)}

.box{background:var(--vy-surface)!important;border:1px solid var(--vy-border)!important;
  border-top:3px solid var(--vy-violet)!important;border-radius:14px!important;box-shadow:0 10px 30px rgba(0,0,0,.25)!important}
.box.box-danger{border-top-color:var(--vy-red)!important}
.box.box-success{border-top-color:var(--vy-green)!important}
.box.box-warning{border-top-color:var(--vy-amber)!important}
.box.box-info{border-top-color:var(--vy-cyan)!important}
.box-header,.box-footer{background:transparent!important;border-color:var(--vy-border)!important;color:var(--vy-text)}
.table>thead>tr>th,.table>tbody>tr>td,.table>tbody>tr>th{border-color:var(--vy-border)!important;color:var(--vy-text)}
.table-hover>tbody>tr:hover{background:rgba(139,92,246,.08)!important}
.form-control{background:var(--vy-bg2)!important;border:1px solid var(--vy-border)!important;color:var(--vy-text)!important;border-radius:10px!important}
.form-control:focus{border-color:var(--vy-violet)!important;box-shadow:0 0 0 3px rgba(139,92,246,.25)!important}
.input-group-addon{background:var(--vy-surface2)!important;border-color:var(--vy-border)!important;color:var(--vy-muted)!important}
.modal-content{background:var(--vy-surface)!important;border:1px solid var(--vy-border)!important;border-radius:16px!important}

.btn{border-radius:10px!important}
.btn-primary{background:var(--vy-grad)!important;border:0!important;color:#fff!important}
.btn-success{background:var(--vy-green)!important;border:0!important;color:#052e1f!important}
.btn-warning{background:var(--vy-amber)!important;border:0!important;color:#2a1d00!important}
.btn-danger{background:var(--vy-red)!important;border:0!important;color:#3b0610!important}
.btn-info{background:var(--vy-cyan)!important;border:0!important;color:#062a33!important}
.btn-default{background:var(--vy-surface2)!important;border-color:var(--vy-border)!important;color:var(--vy-text)!important}
.label-success{background:var(--vy-green)!important;color:#052e1f}
.label-warning{background:var(--vy-amber)!important;color:#2a1d00}
.label-danger{background:var(--vy-red)!important;color:#3b0610}
.label-info{background:var(--vy-cyan)!important;color:#062a33}
.label-default{background:#323852!important}

.alert-warning,.callout-warning{background:rgba(251,191,36,.12)!important;border:1px solid rgba(251,191,36,.45)!important;color:#fde68a!important}
.alert-danger,.callout-danger{background:rgba(251,113,133,.12)!important;border:1px solid rgba(251,113,133,.45)!important;color:#fecdd3!important}
.alert-success,.callout-success{background:rgba(52,211,153,.12)!important;border:1px solid rgba(52,211,153,.45)!important;color:#a7f3d0!important}
.alert-info,.callout-info{background:rgba(34,211,238,.10)!important;border:1px solid rgba(34,211,238,.4)!important;color:#a5f3fc!important}
.main-footer{background:var(--vy-bg2)!important;border-top:1px solid var(--vy-border)!important;color:var(--vy-muted)!important}

/* ===== v1.0.2 PERBAIKAN: spesifisitas lebih tinggi ===== */
html body.skin-blue .wrapper,html body.skin-blue .content-wrapper,html body.skin-blue .right-side{background:var(--vy-bg)!important;color:var(--vy-text)}
html body.skin-blue .main-header .logo,html body.skin-blue .main-header .navbar,html body.skin-blue .main-sidebar,html body.skin-blue .left-side{background:#0c0e16!important}
html body.skin-blue .sidebar-menu>li.header{background:#0a0b11!important}
html body.skin-blue .sidebar-menu>li>.treeview-menu{background:#0a0b11!important}
html body.skin-blue .box{background:var(--vy-surface)!important}
html body.skin-blue .main-footer{background:var(--vy-bg2)!important}
html body.skin-blue .content-wrapper{overflow-x:hidden}
</style>
@endverbatim
